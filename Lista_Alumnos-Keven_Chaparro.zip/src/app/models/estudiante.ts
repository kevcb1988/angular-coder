export interface Estudiante{
    nombre: string,
    carrera: string,
    mensaje: string,
    estado: boolean
}